
public class odd_OR_even {
	public static void main(String[] args) {
		int a=5;
		if(a%2==0)
			System.out.println("the number"+a+" is Even");
		else
			System.out.println("the number"+a+"is Odd");
			
	}

}
