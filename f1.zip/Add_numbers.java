
public class Add_numbers {
	public static void main(String[] args) {
		int a=5,b=6,sum;
		sum=a+b;
		System.out.println("Sum="+sum);
	}

}
