
public class Factorial {
	public static void main(String[] args) {
		int n=5,fact=1,i;
	    for(i=1;i<=n;i++)
	    	fact=fact*i;
		System.out.println("Factorial="+fact);
	}

}
