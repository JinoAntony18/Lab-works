
public class SumOfNatural {
	public static void main(String[] args) {
		int n=5,sum=0,i;
	    for(i=1;i<=n;i++)
	    	sum=sum+i;
	    System.out.println("Sum="+sum);
	}

}
